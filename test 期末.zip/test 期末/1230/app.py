from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/challenge')
def challenge():
    # 获取暂停时间（如果有的话），如果没有默认设置为11秒
    pause_time = request.args.get('pause_time', default=11, type=int)
    return render_template('challenge.html', pause_time=pause_time)

if __name__ == '__main__':
    app.run(debug=True)
