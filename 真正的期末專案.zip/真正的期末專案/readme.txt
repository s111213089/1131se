pip install mysql-connector
pip install Flask
